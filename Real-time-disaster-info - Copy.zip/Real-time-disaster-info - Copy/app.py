from flask import Flask, request,redirect,url_for, render_template,jsonify
from pymongo import MongoClient, errors
# from model.py import store_disaster_data
from dotenv import load_dotenv
# from scrap import thehindu, ndtv,hindustantimes
from data import fetch_ndtv,fetch_theHindu
from feedback import store_user_feedback
import hashlib
import os
import jwt
import datetime
import json

SECRET_KEY = "gencoders"

load_dotenv()

app = Flask(__name__)
mongo_uri = os.getenv("MONGO_URI")

# # MongoDB configuration
# try:
#     client = MongoClient(mongo_uri)
#     db = client['disaster_db']
#     collection = db['disaster_data']
#     print("Database connection successful")
# except errors.ConnectionFailure as e:
#     print(f"Could not connect to MongoDB: {e}")

client = MongoClient(mongo_uri)
db = client['disaster_db']
# collection = db['disaster_data']
users_collection = db['users']
feedback_collection = db['feedback']
alert_collection = db['alert']

def generate_token(email):
    payload = {
        "email": email,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)  # Token expires in 1 hour
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    return token

@app.route('/login', methods=['POST'])
def login():
    email = request.form['login-email']
    password = request.form['login-password']
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    
    user = users_collection.find_one({"email": email, "password": hashed_password})

    if user:
        token = generate_token(email)
        return jsonify({
            "message": "Login successful!",
            "token": token,
            "user": {
                "id": str(user["_id"]),
                "email": user["email"],
                "name": user.get("name"),
            }
        }), 200
    else:
        return jsonify({"message": "Invalid email or password"}), 401

@app.route('/signup', methods=['POST'])
def signup():
    name = request.form['signup-name']
    email = request.form['signup-email']
    password = request.form['signup-password']
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    user = {
        "name": name,
        "email": email,
        "password": hashed_password
    }
    users_collection.insert_one(user)
    return jsonify({"message": "User signed up successfully!"})

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/earthquakes')
def earthquakes():
    return render_template('earthquake.html')

@app.route('/tsunami')
def tsunami():
    return render_template('tsunami.html')

@app.route('/flood')
def flood():
    return render_template('flood.html')

@app.route('/wildfires')
def wildfires():
    return render_template('wildfires.html')

@app.route('/hurricane')
def hurricane():
    return render_template('hurricane.html')

@app.route('/tornado')
def tornado():
    return render_template('tornado.html')

@app.route('/feedback', methods=["POST"])
def feedback():
    name = request.form['name']
    email = request.form['email']
    feedback_text = request.form['feedback']

    feedback_data = {
        "name": name,
        "email": email,
        "feedback": feedback_text
    }

    feedback_collection.insert_one(feedback_data)

    return redirect(url_for('thank_you'))

@app.route('/thank_you')
def thank_you():
    return render_template('index.html')


@app.route('/alerthub', methods=['POST'])
def alerthub():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        whatsapp = request.form['whatsapp']
        
        alert_collection.insert_one({
            'name': name,
            'email': email,
            'whatsapp': whatsapp
        })
    
        return redirect(url_for('home'))


@app.route('/alert_hub')
def alert_Hub():
    return render_template('alerthub.html')

@app.route('/ndtv')
def ndtv():
    return render_template('ndtv.html')

@app.route('/hindu')
def hindu():
    return render_template('thehindu.html')

@app.route('/login')
def logIn():
    return render_template("login_signup.html")
    

# @app.route('/news-data')
# def newsData():
#     site = request.args.get('site')
#     print(site)

#     topics = ['landslide']
#     # topics = ['landslide', 'wildfire', 'flood', 'earthquake', 'drought']

#     if site == "ndtv":
#         data = ndtv(topics)
#         return jsonify({"data": data}), 200
    
#     elif site == "thehindu":
#         data = thehindu(topics)
#         return jsonify({"data": data}), 200
    
#     elif site == "hindustantimes":
#         data = hindustantimes(topics)
#         return jsonify({"data": data}), 200
    
#     else:
#         return jsonify({"error": "Invalid site"}), 400

@app.route('/news-data')
def newsData():
    site = request.args.get('site')
    topics = ['landslide', 'wildfire', 'flood', 'earthquake', 'drought']
    all_news_data = []

    try:
        if site == 'ndtv':
            url = "https://www.ndtv.com/topic"
            for topic in topics:
                news_data = fetch_ndtv(f"{url}/{topic}")
                if news_data:
                    all_news_data.extend(news_data)
            

        elif site == "Hindu":
            url = "https://www.thehindu.com/search/#gsc.tab=0&gsc.q="
            for topic in topics:
                news_data = fetch_theHindu(f"{url}={topic}")
                if news_data:
                    all_news_data.extend(news_data)
    

        if not all_news_data:
            return jsonify({"error": "No news data found for the requested topics"}), 404

        return jsonify(all_news_data), 200

    except Exception as e:
        return jsonify({"error": "An error occurred while fetching news data"}), 500
# # Route to trigger scraping and store data in MongoDB
# @app.route('/scrape')
# def scrape():
#     articles = scrape_all_sites(topics)

#     # Process and store data in MongoDB
#     disaster_info = []
#     for website, articles_dict in articles.items():
#         for topic, article_texts in articles_dict.items():
#             disaster_info.append({
#                 'website': website,
#                 'topic': topic,
#                 'articles': article_texts
#             })

#     try:
#         # Insert only new data to avoid duplication
#         existing_data = list(collection.find({}, {'_id': 0}))
#         new_data = [item for item in disaster_info if item not in existing_data]
#         if new_data:
#             collection.insert_many(new_data)
#         return jsonify(disaster_info), 200
#     except requests.RequestException as e:
#         return jsonify({"error": f"Request error: {e}"}), 500
#     except Exception as e:
#         return jsonify({"error": f"An error occurred: {e}"}), 500

# # Route to get all disaster data
# @app.route('/disasters' )
# def disasters():
#     try:
#         disasters = list(collection.find({}, {'_id': 0}))
#         return jsonify(disasters), 200
#     except Exception as e:
#         return jsonify({"error": f"Failed to retrieve data: {e}"}), 500

# # Route to filter disaster data by region
# @app.route('/disasters/<region>')
# def get_disasters_by_region(region):
#     try:
#         disasters = list(collection.find({"affected_region": region}, {'_id': 0}))
#         return jsonify(disasters), 200
#     except Exception as e:
#         return jsonify({"error": f"Failed to retrieve data for region {region}: {e}"}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5000)