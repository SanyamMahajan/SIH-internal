# Import necessary libraries
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time
from dotenv import load_dotenv
import os

load_dotenv()
driver_path = os.getenv("DRIVER_PATH")

# Function definition for Google News


# Function definition for Times of India


def hindustantimes(url_list):
    service = Service(executable_path= r"C:\Users\Prinkal Sanyam\Desktop\tech installed\chromedriver-win64\chromedriver.exe")
    driver = webdriver.Chrome(service=service)
    article_dict = {}
    for url in url_list:
        site = f"https://www.hindustantimes.com/topic/{url}"
        driver.get(site)
        time.sleep(5)
        divs = driver.find_elements(By.CLASS_NAME, "listingPage")
        article_texts = [div.text for div in divs]
        article_dict[url] = article_texts

    driver.quit()
    return article_dict

def ndtv(url_list):
    service = Service(executable_path=r"C:\Users\Prinkal Sanyam\Desktop\tech installed\chromedriver-win64\chromedriver.exe")
    driver = webdriver.Chrome(service=service)
    article_dict = {}
    for url in url_list:
        site = f"https://www.ndtv.com/search?searchtext={url}"
        driver.get(site)
        time.sleep(5)
        divs = driver.find_elements(By.CLASS_NAME, "srh_tab-wrp")
        article_texts = [div.text for div in divs]
        article_dict[url] = article_texts

    driver.quit()
    return article_dict

def thehindu(url_list):
    service = Service(executable_path=r"C:\Users\Prinkal Sanyam\Desktop\tech installed\chromedriver-win64\chromedriver.exe")
    driver = webdriver.Chrome(service=service)
    article_dict = {}
    for url in url_list:
        site = f"https://www.thehindu.com/search/#gsc.tab=0&gsc.q={url}"
        driver.get(site)
        time.sleep(5)
        divs = driver.find_elements(By.CLASS_NAME, "gsc-control-wrapper-cse")
        article_texts = [div.text for div in divs]
        article_dict[url] = article_texts

    driver.quit()
    return article_dict


