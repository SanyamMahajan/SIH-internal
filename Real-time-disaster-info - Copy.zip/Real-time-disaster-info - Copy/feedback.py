from pymongo import MongoClient
from datetime import datetime
from dotenv import  load_dotenv
import os

load_dotenv()
mongo_uri = os.getenv("MONGO_URI")

def store_disaster_data(disaster_data):
    try:
        client = MongoClient(mongo_uri)
        db = client['terManagementDB']
        db.areas.delete_many({})  # Clear existing data
        if disaster_data:  # Check if there is data to insert
            db.areas.insert_many(disaster_data)
            print("Disaster data stored successfully!")
        else:
            print("No disaster data to store.")
    except Exception as e:
        print(f"Error storing disaster data in MongoDB: {e}")

def store_user_feedback(feedback):
    '''
    in the format 
    {
    username : username
    general_feedback : string feedback
    timestamp : datetime.now()
    }
    '''
    try:
        client = MongoClient(mongo_uri)
        db = client['terManagementDB']
        db.feedback.insert_one(feedback)
        print("User feedback stored successfully!")
    except Exception as e:
        print(f"Error storing user feedback in MongoDB: {e}")

